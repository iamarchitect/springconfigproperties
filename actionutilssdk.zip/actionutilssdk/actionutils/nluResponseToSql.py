'''
Created on 20-Jan-2019

@author: asarkar
'''

import logging

from actionutils.nludsl import NluDsl
logger = logging.getLogger(__name__)

OPERATORS = {}
OPERATORS["LT"]= " < "
OPERATORS["GT"]= " > "
OPERATORS["LTE"]= " <= "
OPERATORS["GTE"]= " >= "
OPERATORS["EQ"]= " = "
OPERATORS["LIKE"]= " LIKE "
OPERATORS["AND"]= " AND "
OPERATORS["and"]= " AND "
OPERATORS["OR"]= " OR "
OPERATORS["or"]= " OR "
OPERATORS["IN"]= " IN "
OPERATORS["BETWEEN"]=" BETWEEN "
OPERATORS["NOT_BETWEEN"]=" NOT BETWEEN "
OPERATORS["NOT_IN"]=" NOT IN "
OPERATORS["IS_NOT"]=" IS NOT "
OPERATORS["IS"]=" IS "
OPERATORS["NOT_LT"]=" >= "
OPERATORS["NOT_GTE"]=" < "
OPERATORS["NOT_LTE"]=" > "
OPERATORS["NOT_EQ"]=" <> "
OPERATORS["NOT_LIKE"]= " NOT LIKE "
ALAIS_SEPARATOR = "."


class NluDSLResponseToSQL(object):
    '''
    classdocs
    '''


    def __init__(self, params,projectionList=None):
        '''
        Constructor
        '''
        self.dsldata = params
        self.projectionList = projectionList
        self.selectStatement = None
        self.whereClause = None
        
        
    
    def __getOperator(self,param):
    
        return OPERATORS[param['operator']]
    
    
    def __getLikeValueByFieldType(self,param,fieldType):
    
        if fieldType == 'num':
        #print("We will not be able to concatenate strings and integers in Python")
            return "%"+str(param)+"%"
    
        elif fieldType == 'text':
        
            return "'%"+param+"%'"
    
        elif fieldType == 'date':
        
            return "'%"+param+"%'"
    
    
    def __getInValueByFieldType(self,param,fieldType):
    
        if fieldType == 'num':
        #print("We will not be able to concatenate strings and integers in Python")
            return str(param)
    
        elif fieldType == 'text':
        
            return "'"+param+"'"
    
        elif fieldType == 'date':
        
            return "'"+param+"'"
        
        
    def __getLikeValue(self,param):
        
        if param['operator']=='LIKE':
             
            like = self.__getLikeValueByFieldType(param['value'],param['fieldType'])
             
            return like
        
    def __getSubQuery(self,param):
        
        return param['subQuery']
        
        
    def __getInValue(self,param):
        
        if param['value']!=None and len(param['value'])>0:
            
            totalLen = len(param['value'])
            indexCounter = 0
            inValueStr = ""
        
            while indexCounter < totalLen:
            
                if indexCounter == totalLen-1:
                    inValueStr = inValueStr + self.__getInValueByFieldType(param['value'][indexCounter],param['fieldType']) 
                else:
                    inValueStr = inValueStr + self.__getInValueByFieldType(param['value'][indexCounter],param['fieldType']) +  " , "
                
            
                indexCounter = indexCounter + 1
            
            
            #print("Final inValueStr")
        
            inValueStr = "( " + inValueStr + " )"
            
            return inValueStr
            

    
    def __getBetweenValue(self,param):
    
        if param['fieldType'] == 'num':

            return str(param['value'][0]) + " AND " + str(param['value'][1])
    
        elif param['fieldType'] == 'text':
        
            return "'"+param['value'][0]+"'" + " AND " + "'"+param['value'][1]+"'"
    
        elif param['fieldType'] == 'date':
        
            return "'"+param['value'][0]+"'" + " AND " + "'"+param['value'][1]+"'"
    
    
    def __getValue(self,param):
    
        if param['operator']=="BETWEEN" or param['operator']=="NOT_BETWEEN":
            return self.__getBetweenValue(param)
        elif param['operator']=="IN" or param['operator']=="NOT_IN":
            return self.__getInValue(param)
        elif param['operator']=="LIKE":
            return self.__getLikeValue(param)
    
        if param['fieldType'] == 'num':
            #print("We will not be able to concatenate strings and integers in Python")
            return str(param['value'])
    
        elif param['fieldType'] == 'text':
        
            return "'"+param['value']+"'"
    
        elif param['fieldType'] == 'date':
            
            if param['value']==None:
                return "NULL"
            else:
                return "'"+param['value']+"'"
    
    
    
    def __getWhereCondtion(self,data):
    
        if 'operator' in data:
            
            return self.__getWhereClause(data)
    
        elif 'field' in data:
            mydata = data['field']
            
            if 'aliasName' in mydata and mydata['aliasName']!=None:
                if 'subQuery' in mydata and mydata['subQuery']!=None:
                    retRes = mydata['aliasName']+ALAIS_SEPARATOR+mydata['name'] +" "+OPERATORS["IN"]+"  ( " + self.__getSubQuery(mydata)+" )"
                else:
                    retRes = mydata['aliasName']+ALAIS_SEPARATOR+mydata['name'] +" "+self.__getOperator(mydata)+" " + self.__getValue(mydata)
            else:
                if 'subQuery' in mydata and mydata['subQuery']!=None:
                    retRes = mydata['name'] +" "+OPERATORS["IN"]+"  ( " + self.__getSubQuery(mydata)+" )"
                else:
                    retRes = mydata['name'] +" "+self.__getOperator(mydata)+" " + self.__getValue(mydata)
        
            return retRes
        
        elif 'nestedfield' in data:
            
            nestedfielddata = data['nestedfield']
            nestedKeyName = "";
            for aKey in nestedfielddata.keys():
                nestedKeyName = aKey
            
            nestedFields = nestedfielddata[nestedKeyName]
            
            where_clause = " nested('"+nestedKeyName+"',"
            
            #print("where_clausewhere_clausewhere_clausewhere_clause    ",data   )
            
            for param in nestedFields:
                
                where_clause = where_clause + self.__getWhereCondtion(param)
                
                #print("where_clausewhere_clausewhere_clausewhere_clause    ",where_clause   )
                
            return where_clause +")"
    

    def __getWhereClause(self,data):
    
        retRes = "  "+ self.__getOperator(data)
    
        return retRes

    
    def __process(self,data):
        '''
        :param data: JSON Object (dict). 
        :param parameters: dict.
        :return: where clause (str) built from data
        '''
    
        where_clause = ""
    
        if isinstance(data, dict):
            
            #print("Inside dict")
        
            where_clause = where_clause + self.__getWhereCondtion(data)
            
        elif isinstance(data, list):
            
            #print("Inside list 1")
        
            for param in data:

                if isinstance(param, list):
                    #print("Inside list 2")
                    #print(where_clause)
                    where_clause = where_clause + "("
                    where_clause = where_clause + self.__process(param)
                    where_clause = where_clause + ")"
                    #print("Inside list 3")
                    #print(where_clause)
                
                elif isinstance(param, dict):
                
                    where_clause = where_clause + self.__getWhereCondtion(param)

                elif isinstance(param, str):
                
                    return param
                
        elif isinstance(data, str):
        
            return data

        return where_clause
    
    
    def parseDSLExpression(self):
        
        expression = self.dsldata["expressions"]
        
        where_clause = self.__process(expression)
        
        self.whereClause = where_clause
    
        return where_clause
    
    def parseDSL(self,isJoin=False):
        
        expression = self.dsldata["expressions"]
        #print("expression parseDSL")
        #print(expression)
        where_clause = None
        try:
            where_clause = self.__process(expression)
        except Exception as exp:
            logger.error("Exception Occured parseDSL "+str(exp))
            logger.error("{0}".format(exp))
    
        #print("====where_clause===parseDSL")
        #print(where_clause)
        
        if isJoin == False:
            tableName = self.dsldata["entities"]
            if self.projectionList==None:
                selectStatement = "SELECT * FROM "+tableName+" where " + where_clause
            else:
                projectionName = ''
                index = 0
                for proj in self.projectionList:
                    if index < len(self.projectionList)-1:
                        projectionName = projectionName + proj + ','
                    else:
                        projectionName = projectionName + proj
                         
                    index = index +1
                    
                selectStatement = "SELECT "+projectionName+" FROM "+tableName+" where " + where_clause
            self.selectStatement = selectStatement
        else:

            selectStatement =self.dsldata["entities"]+" WHERE " + where_clause
            self.selectStatement = selectStatement
    
        return selectStatement
    
    def displaySQL(self):
        
        #print("Displaying SQL ")
        
        print(self.selectStatement)
        print(self.whereClause)
        
    def createResponseText(self,inputText,query=None,dsl=None,residualStr=None,persons=None,allEntities=None,errorMessage=None):
        
        print("===query===")
        print(query)
        
        responseText = {}
        responseText['query']=query
        responseText['dsl']=dsl
        responseText['inputText']=inputText
        responseText['unextractedText']=residualStr
        responseText['persons']=persons
        responseText['allEntities']=allEntities
        
        if errorMessage!=None:
            responseText['errorMessage']=errorMessage
        
        return responseText
        
