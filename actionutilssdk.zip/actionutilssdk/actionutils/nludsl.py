'''
Created on 20-Jan-2019

@author: asarkar
'''

import datetime
import time


# INDICIESMAP = {}
# #INDICIESMAP['globalsearch']="globalsearch_set" #QA
# #INDICIESMAP['globalsearch']="globalsearch_final" #DEV
# INDICIESMAP['globalsearch']="globalsearch_optimized" #UAT


# ATTRIBUEMAP = {}
# 
# ATTRIBUEMAP['search_attribute']="search_attribute"
# ATTRIBUEMAP["speciality"]= "speciality"
# ATTRIBUEMAP["taxonomy"]= "taxonomydesc.raw"
# ATTRIBUEMAP["applicationType"]= "ApplnType.raw"
# ATTRIBUEMAP["practiceType"]= "P_PRACT_TY_CD.raw"
# ATTRIBUEMAP["providerType"]= "TypeDescription.raw"
# 
# ATTRIBUEMAP['ssn']="Provider_SSN.raw"
# ATTRIBUEMAP['npi']="Provider_NPI.raw"




class NluDsl(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self.dslObject = None
        
#     def getAttributeName(self,attributeName):
#         
#         return ATTRIBUEMAP[attributeName]
        
    def addOperator(self,operatorVal,mydata):
        
        if self.isSupportedOperator(operatorVal)==False:
            self.operatorNotSupportExecption(operatorVal)
    
        mydata['operator']=operatorVal
    
        return mydata
    
    def addDefaultOperator(self,mydata):
    
        mydata['operator']="AND"
    
        return mydata
    

    def addField(self,fieldName,operatorVal,value,fieldTypeVal,aliasName=None,subQuery=None):
        
        if self.isSupportedOperator(operatorVal)==False:
            self.operatorNotSupportExecption(operatorVal)
        
        field={}
        fieldMetaData={}
        fieldMetaData['name']=fieldName
        fieldMetaData['operator']=operatorVal
        fieldMetaData["value"]=value
        fieldMetaData['fieldType']=fieldTypeVal
        fieldMetaData['aliasName']=aliasName
        fieldMetaData['subQuery']=subQuery
        
        field["field"]=fieldMetaData
        
        return field

    def addEntities(self,entityNames):
    
        dsl={}
        dsl["entities"]=entityNames
        expressions = []
        dsl["expressions"]=expressions
        
        self.dslObject=dsl
    
        return dsl
    
    def displayDSL(self):
        pass
        #print(self.dslObject)
        
    def isSupportedOperator(self,param):
        
        for opsu in self.operatorSupported():
            if param == opsu:
                return True
            
        
        return False
        
    def operatorSupported(self):
        
        return ["IS","LT","GT","LTE","GTE","EQ","LIKE","IN","AND","OR","BETWEEN","NOT_IN","NOT_BETWEEN","IS_NOT","NOT_LT","NOT_LTE","NOT_GTE","NOT_EQ"]
    
    def operatorNotSupportExecption(self,param):
        
        raise RuntimeError('Operator Not Support Exception for '+param)
    
    
    def _getDateValue(self,value):
         
        return value.split("T")[0]
    
    def _getDateTimeValue(self,value):
         
        return value.replace("-06:00","Z")
    
    def _getDateTodayValue(self,value):
        
        return value.split("T")[0]+"T00:00:00.000Z"
    
    def _getExtactDateValue(self,value):
        
        if value!=None and value!="DATEIGNORE":
            return value.split("T")[0]
    
    def getDateFieldDSLValue(self,dataObject):
        
        dateFieldDSLValue = {}
        
        if isinstance(dataObject, str):
            dateFieldDSLValue["operator"]="EQ"
            dateFieldDSLValue["dateValue"]=self._getExtactDateValue(dataObject)
            dateFieldDSLValue["isDateRange"]=False
            print("NSL print(dateFieldDSLValue)")
            print(dateFieldDSLValue)
            
            return dateFieldDSLValue
        
        
        
        dateValues=[]
        fromValue=None
        toValue=None
                    
        if 'from' in dataObject and dataObject['from']!=None:
            fromValue = self._getDateValue(dataObject['from'])
            dateValues.append(fromValue)                
                        
        if 'to' in dataObject and dataObject['to']!=None:
            toValue = self._getDateTimeValue(dataObject['to'])
            dateValues.append(toValue)
        else:
            #From date is available and less than current date, then to date is by default currentSystem date
            date_format = "%Y-%m-%d"
            if fromValue !=None:
                fromValueTime = time.strptime(fromValue, date_format)
                todayDate = str(datetime.datetime.today().strftime(date_format))
                currentValueTime = time.strptime(todayDate, date_format)
                if currentValueTime > fromValueTime:
                    todayDateF = datetime.datetime.today() + datetime.timedelta(days=1)
                    todayDateF = datetime.datetime.fromtimestamp(todayDateF.timestamp()).isoformat()
                    todayDateFinal= self._getDateTodayValue(todayDateF)
                    dateValues.append(todayDateFinal)
                
            
                        
        if len(dateValues)==2:
            dateFieldDSLValue["operator"]="BETWEEN"
            dateFieldDSLValue["dateValue"]=dateValues
        else:
            if fromValue != None and toValue == None:
                dateFieldDSLValue["operator"]="GTE"
                dateFieldDSLValue["dateValue"]=fromValue
            else:
                dateFieldDSLValue["operator"]="LT"
                dateFieldDSLValue["dateValue"]=toValue
                
        
        dateFieldDSLValue["isDateRange"]=True
                            
        return dateFieldDSLValue
    
