from functools import lru_cache
import configparser
import os
import shutil

filename = './config/config.txt'

@lru_cache()
def ret_config_urls(section):
    config = configparser.RawConfigParser()
    config.read(filename)
    details_dict = dict(config.items(section))
    return details_dict

# def ret_config_urlval(section,keys):
#     ret_config_urls.cache_clear()
#     config_items=ret_config_urls(section)
#     return config_items[keys]

## remove old pickles
def clear_pickle_directory(model_dir,project_name):
    if os.path.exists(model_dir):
        direc = model_dir+'/'+project_name
        if os.path.exists(direc) and len(os.listdir(direc))>0:
            shutil.rmtree(model_dir+'/'+project_name)

# class ConfigControllerParams(object):
#     
#     def __init__(self, confFile,):
#         self._params = params
# 
#     def getConfigParams(self):
#         return self._params