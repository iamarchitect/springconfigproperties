'''
Created on 17-Jun-2019

@author: asarkar
'''
from actions.attributeValueMapper import getFieldDefinaton
from actionutils.nluResponseToSql import NluDSLResponseToSQL
from actionutils.nludsl import NluDsl


def callme():
    nludsl = NluDsl()
    emailResult1 = nludsl.addField("age", "EQ", 32, "num", "a")
    
    subQueryDSL = NluDsl()
    subQueryEntities = subQueryDSL.addEntities('SECURITY')
    subQResult = subQueryEntities["expressions"]
    nameList = []
    nameList.append("Sahil")
    nameList.append("Sarkar")
    queryList = []
    queryList.append(subQueryDSL.addField("firstName", "IN", nameList, "text"))
    queryList.append(subQueryDSL.addOperator("OR",{}))
    queryList.append(subQueryDSL.addField("lastName", "IN", nameList, "text"))
    subQResult.append(queryList)
    projectionList = []
    projectionList.append("userId")
    projectionList.append("loggId")
    sqSQL = NluDSLResponseToSQL(subQueryEntities,projectionList)
    sqStatement = sqSQL.parseDSL(False)
    
    emailResult2 = nludsl.addField("firstName", "IN", "", "text", "b",sqStatement)
    emailResult3 = nludsl.addField("name", "EQ", "Anal", "text", "b")
     
    #nested
    nestedDSL = []
    nestedDSL.append(nludsl.addField('ConsultDetails'+'.'+'consultedstatus', "EQ", "CP", "text","b"))
    #fresult = nludsl.addEntities('globalsearch')
     
     
    fresult = {}
    fresult["expressions"]=[]
    result = fresult["expressions"]
    result.append(emailResult1)
    result.append(nludsl.addDefaultOperator({}))
    result.append(emailResult2)
    result.append(nludsl.addDefaultOperator({}))
    result.append(emailResult3)
    result.append(nludsl.addDefaultOperator({}))
    result.append({"nestedfield":{"ConsultDetails":nestedDSL}})
     
     
     
    nluDSLResponseToSQL = NluDSLResponseToSQL(fresult)
    nluDSLResponseToSQL.parseDSLExpression()
    nluDSLResponseToSQL.displaySQL()
    
#     ss = getFieldDefinaton("assigned")
#     print(ss)
#     if ss !=None:
#         print(ss.display())
    


if __name__ == '__main__':
    callme()