'''
Created on 18-Jun-2019

@author: asarkar
'''

RESOLUTION_STATUS_ATTRIBUTE_NAME = "activityDetails.userAction"
RESOLUTIONSTATUSMAP={}
RESOLUTIONSTATUSMAP["approve"] = "Approve"
RESOLUTIONSTATUSMAP["approved"] = "Approved"
RESOLUTIONSTATUSMAP["denied"] = "Denied"

RESOLUTIONSTATUSMAP["deficiency notice sent"] = "Deficiency Notice Sent"
#RESOLUTIONSTATUSMAP["deficiency notice"] = "Deficiency Notice Sent"

#RESOLUTIONSTATUSMAP["enrolled"] = "Enrolled/Provisional Status Granted"
RESOLUTIONSTATUSMAP["enrolled/provisional status granted"] = "Enrolled/Provisional Status Granted"
#RESOLUTIONSTATUSMAP["provisional status granted"] = "Enrolled/Provisional Status Granted"
#RESOLUTIONSTATUSMAP["provisional"] = "Enrolled/Provisional Status Granted"
#RESOLUTIONSTATUSMAP["provisional status"] = "Enrolled/Provisional Status Granted"
RESOLUTIONSTATUSMAP["close as duplicate"] = "Close as Duplicate"
RESOLUTIONSTATUSMAP["close with out account update"] =  "Close With Out Account Update"
#RESOLUTIONSTATUSMAP["close without account update"] =  "Close With Out Account Update"
RESOLUTIONSTATUSMAP["disenrolled"] = "DisEnrolled"

RESOLUTIONSTATUSMAP["reviewcancelled"] = "ReviewCancelled"
RESOLUTIONSTATUSMAP["closedduplicate"] = "ClosedDuplicate"


MILESTONE_ATTRIBUTE_NAME = "milestoneDetails.milestoneName"   # Nested milestoneDetails.milestoneName  earlier--> # "MILESTONE.raw"
MILESTONEMAP={}
MILESTONEMAP["automated screening"] = "Automated Screening"
MILESTONEMAP["closed"] = "Closed"
MILESTONEMAP["received"]="Received"
MILESTONEMAP["inportal"] = "InPortal"
MILESTONEMAP["submitted"] = "Submitted"
MILESTONEMAP["accepted in enrollment"] = "Accepted in Enrollment"
MILESTONEMAP["case assignment"] = "Case Assignment"
MILESTONEMAP["screening review"] = "Screening Review"
MILESTONEMAP["application review"] = "Application Review"
#MILESTONEMAP["app review"] = "Application Review"
#MILESTONEMAP["appl review"] = "Application Review"
MILESTONEMAP["referred"] = "Referred"
MILESTONEMAP["reverted"] = "Reverted"
MILESTONEMAP["proposed resolution"] = "Proposed Resolution"
MILESTONEMAP["closed"] = "Closed"
MILESTONEMAP["approved or denied"] = "Approved or Denied"

#################################################################

WORKFLOW_ATTRIBUTES=["due","received","closed","open","completed","resolved","closeddate","completeddate","resolveddate","rtp","RTP","rtpdate","resubmitted","resubmitteddate","overdue"]

WORKFLOW_STATUS_VALUE_CODE_MAP={}
WORKFLOW_STATUS_VALUE_CODE_MAP["COMPLETED"]="COMPLETED"
WORKFLOW_STATUS_VALUE_CODE_MAP["TERMINATED"]="TERMINATED"
WORKFLOW_STATUS_VALUE_CODE_MAP["SUSPEND"]="SUSPEND"
WORKFLOW_STATUS_VALUE_CODE_MAP["INPROGRESS"]="INPROGRESS"

WORKFLOW_REASON_CODE={}
WORKFLOW_REASON_CODE["RESUBMIITED"]="04"
WORKFLOW_REASON_CODE["RTP"]="RTP-01"

WORKFLOW_STATUS_CODES={}
WORKFLOW_STATUS_CODES["closed"]=[WORKFLOW_STATUS_VALUE_CODE_MAP["COMPLETED"],WORKFLOW_STATUS_VALUE_CODE_MAP["TERMINATED"]]
WORKFLOW_STATUS_CODES["completed"]=WORKFLOW_STATUS_CODES["closed"]
WORKFLOW_STATUS_CODES["resolved"]=WORKFLOW_STATUS_CODES["closed"]
WORKFLOW_STATUS_CODES["open"]=[WORKFLOW_STATUS_VALUE_CODE_MAP["INPROGRESS"],WORKFLOW_STATUS_VALUE_CODE_MAP["SUSPEND"]]

WORKFLOW_ATTRIBUTE_NAME_MAP={}
WORKFLOW_ATTRIBUTE_NAME_MAP["due"]= {"entityType":"time","fieldType":"date","fieldName":"dueDate","defaultValue":None,"relatedFields":[]}
WORKFLOW_ATTRIBUTE_NAME_MAP["received"]= {"entityType":"time","fieldType":"date","fieldName":"createdAt","defaultValue":None,"relatedFields":[]}
WORKFLOW_ATTRIBUTE_NAME_MAP["closed"]= {"entityType":"caseStatus","fieldType":"text","fieldName":"workflowStatus","defaultValue":{"operator":"IN","data":WORKFLOW_STATUS_CODES["closed"]},"relatedFields":[{"fieldType":"date","fieldName":"closeddate"}]}
WORKFLOW_ATTRIBUTE_NAME_MAP["resolved"]= WORKFLOW_ATTRIBUTE_NAME_MAP["closed"]
WORKFLOW_ATTRIBUTE_NAME_MAP["completed"]= WORKFLOW_ATTRIBUTE_NAME_MAP["closed"]
WORKFLOW_ATTRIBUTE_NAME_MAP["open"]= {"entityType":"caseStatus","fieldType":"text","fieldName":"workflowStatus","defaultValue":{"operator":"IN","data":WORKFLOW_STATUS_CODES["open"]},"relatedFields":[]}
WORKFLOW_ATTRIBUTE_NAME_MAP["closeddate"]= {"entityType":"time","fieldType":"date","fieldName":"completedAt","defaultValue":None,"relatedFields":[]}
WORKFLOW_ATTRIBUTE_NAME_MAP["completeddate"]= WORKFLOW_ATTRIBUTE_NAME_MAP["closeddate"]
WORKFLOW_ATTRIBUTE_NAME_MAP["resolveddate"]= WORKFLOW_ATTRIBUTE_NAME_MAP["closeddate"]

WORKFLOW_ATTRIBUTE_NAME_MAP["rtp"]= {"entityType":"caseStatus","fieldType":"text","fieldName":"activityDetails.suspendActionReasonCode","defaultValue":{"operator":"EQ","data":WORKFLOW_REASON_CODE["RTP"]},"relatedFields":[{"fieldType":"date","fieldName":"rtpdate"}]}
WORKFLOW_ATTRIBUTE_NAME_MAP["RTP"]=WORKFLOW_ATTRIBUTE_NAME_MAP["rtp"]
WORKFLOW_ATTRIBUTE_NAME_MAP["resubmitted"]= {"entityType":"caseStatus","fieldType":"text","fieldName":"activityDetails.resumeActionReasonCode","defaultValue":{"operator":"EQ","data":WORKFLOW_REASON_CODE["RESUBMIITED"]},"relatedFields":[{"fieldType":"date","fieldName":"resubmitteddate"}]}
WORKFLOW_ATTRIBUTE_NAME_MAP["rtpdate"]= {"entityType":"time","fieldType":"date","fieldName":"activityDetails.suspendActionCreateAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}
WORKFLOW_ATTRIBUTE_NAME_MAP["resubmitteddate"]= {"entityType":"time","fieldType":"date","fieldName":"activityDetails.resumeActionCreateAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}



WORKFLOW_ATTRIBUTE_NAME_MAP["overdue"] = WORKFLOW_ATTRIBUTE_NAME_MAP["due"]


#################################################################

ACTIVITY_ATTRIBUTES=["assigned","screened","rescreened","re-screened","activityStartDate","activityEndDate","activityId"]

ACTIVITY_STATUS_VALUE_CODE_MAP={}
ACTIVITY_STATUS_VALUE_CODE_MAP["TODO"]="TODO"
ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNED"]="ASSIGNED"
ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNMENT_REQUESTED"]="ASSIGNMENT_REQUESTED"
ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNMENT_ACCEPTED"]="ASSIGNMENT_ACCEPTED"
ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNMENT_REJECTED"]="ASSIGNMENT_REJECTED"
ACTIVITY_STATUS_VALUE_CODE_MAP["INPROGRESS"]="INPROGRESS"
ACTIVITY_STATUS_VALUE_CODE_MAP["COMPLETED"]="COMPLETED"
ACTIVITY_STATUS_VALUE_CODE_MAP["SUSPEND"]="SUSPEND"


ACTIVITY_STATUS_CODES={}
ACTIVITY_STATUS_CODES["assigned"]=[ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNED"],ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNMENT_ACCEPTED"],ACTIVITY_STATUS_VALUE_CODE_MAP["ASSIGNMENT_REQUESTED"]]

ACTIVITY_STATUS_CODES["screened"]="SCREENED"
ACTIVITY_STATUS_CODES["rescreened"]="RESCREENED"
ACTIVITY_STATUS_CODES["re-screened"]=ACTIVITY_STATUS_CODES["rescreened"]


ACTIVITY_ATTRIBUTE_NAME_MAP={}
ACTIVITY_ATTRIBUTE_NAME_MAP["assigned"]={"entityType":"caseStatus","fieldType":"text","fieldName":"activityDetails.activityState","defaultValue":{"operator":"IN","data":ACTIVITY_STATUS_CODES["assigned"]},"relatedFields":[{"fieldType":"date","fieldName":"activityStartDate"}]}
ACTIVITY_ATTRIBUTE_NAME_MAP["activityStartDate"]={"entityType":"time","fieldType":"date","fieldName":"activityDetails.createdAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}

ACTIVITY_ATTRIBUTE_NAME_MAP["screened"]={"entityType":"caseStatus","fieldType":"text","fieldName":"activityDetails.activityName","defaultValue":{"operator":"EQ","data":ACTIVITY_STATUS_CODES["screened"]},"relatedFields":[{"fieldType":"date","fieldName":"activityStartDate"}]}
ACTIVITY_ATTRIBUTE_NAME_MAP["rescreened"]={"entityType":"caseStatus","fieldType":"text","fieldName":"activityDetails.activityName","defaultValue":{"operator":"EQ","data":ACTIVITY_STATUS_CODES["rescreened"]},"relatedFields":[{"fieldType":"date","fieldName":"activityStartDate"}]}
ACTIVITY_ATTRIBUTE_NAME_MAP["re-screened"]=ACTIVITY_ATTRIBUTE_NAME_MAP["rescreened"]

ACTIVITY_ATTRIBUTE_NAME_MAP["activityEndDate"]={"entityType":"time","fieldType":"date","fieldName":"activityDetails.updatedAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}

ACTIVITY_ATTRIBUTE_NAME_MAP["activityId"]={"entityType":"activityId","fieldType":"text","fieldName":"currentActivityDetails.activityDefId","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}

###############################################################

CONSULT_DETAIL_ATTRIBUTES=["consulteddate","consulted with","consulted by","reverteddate","consultexpireddate","consulted","reverted"]

CONSULT_DETAIL_STATUS_VALUE_CODE_MAP={}
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["TODO"]=0
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNED"]=1
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNMENT_REQUESTED"]=2
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNMENT_ACCEPTED"]=3
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNMENT_REJECTED"]=4
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["INPROGRESS"]=5
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["COMPLETED"]=6
#CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["SUSPEND"]=7

CONSULT_DETAIL_STATUS_CODES={}
#CONSULT_DETAIL_STATUS_CODES["assigned"]=[CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNED"]]
#CONSULT_DETAIL_STATUS_CODES["screened"]=[CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNED"]]
#CONSULT_DETAIL_STATUS_CODES["re-screened"]=[CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNED"]]
#CONSULT_DETAIL_STATUS_CODES["rescreened"]=[CONSULT_DETAIL_STATUS_VALUE_CODE_MAP["ASSIGNED"]]


CONSULT_DETAIL_ATTRIBUTE_NAME_MAP={}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["consulteddate"]={"entityType":"time","fieldType":"date","fieldName":"consultDetails.createdAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[{"fieldType":"date","fieldName":"consultexpireddate"}]}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["reverteddate"]={"entityType":"time","fieldType":"date","fieldName":"consultDetails.completedAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["consulted with"]={"entityType":"consultedwith","fieldType":"text","fieldName":"consultDetails.consultedWith","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[{"fieldType":"date","fieldName":"consulteddate"},{"fieldType":"date","fieldName":"reverteddate"}]}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["consulted by"]={"entityType":"consultedby","fieldType":"text","fieldName":"consultDetails.consultedBy","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[{"fieldType":"date","fieldName":"consulteddate"},{"fieldType":"date","fieldName":"reverteddate"}]}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["consultexpireddate"]={"entityType":"time","fieldType":"date","fieldName":"consultDetails.consultExpiredAt","defaultValue":{"operator":"IS","data":"NULL"},"relatedFields":[]}


CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["consulted"]={"entityType":"caseStatus","fieldType":"date","fieldName":"consultDetails.createdAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[{"fieldType":"date","fieldName":"consulteddate"},{"fieldType":"date","fieldName":"reverteddate"}]}
CONSULT_DETAIL_ATTRIBUTE_NAME_MAP["reverted"]={"entityType":"caseStatus","fieldType":"date","fieldName":"consultDetails.completedAt","defaultValue":{"operator":"EQ","data":"NOT NULL"},"relatedFields":[]}

###############################################################




class AttributeDefination(object):
    '''
    classdocs
    '''
    
    def __init__(self,params):
        '''
        Constructor
        '''
        self._fieldDataType=params.get('fieldType')
        self._fieldName=params.get('fieldName')
        self._entityType=params.get('entityType')
        self._operator = None
        self._data = None
        self._relatedFields = None
        
        if params.get('defaultValue')!=None:
            self._operator = params.get('defaultValue').get('operator')
            self._data = params.get('defaultValue').get('data')
        if params.get('relatedFields')!=None:
            self._relatedFields = params.get('relatedFields')
            
        
        
    def getName(self):
        return self._fieldName
    
    def getDataType(self):
        return self._fieldDataType
    
    def getDefaultOperator(self):
        return self._operator
    
    def getDefaultData(self):
        return self._data
    
    def getRelatedFields(self):
        return self._relatedFields
    
    def getEntityType(self):
        return self._entityType
    
    def display(self):
        return "entityType : "+str(self._entityType) +" , name : "+str(self._fieldName) + " , dataType: "+str(self._fieldDataType)+ " , defaultOperator: "+str(self._operator)+" , defaultData: "+str(self._data)+" , relatedFields: "+str(self._relatedFields)


class WAFieldDefination(object):
    '''
    classdocs
    '''

    def __init__(self,fieldName=None,entityType=None,fieldBelongsTo=None,fieldDefaultValue=None,fieldDataType=None,fieldDefaultOperator=None,relatedFields=[]):
        '''
        Constructor
        '''
        self._fieldName=fieldName
        self._entityType=entityType
        self._fieldBelongsTo=fieldBelongsTo
        self._fieldDefaultValue=fieldDefaultValue
        self._fieldDataType=fieldDataType
        self._fieldDefaultOperator=fieldDefaultOperator
        self._relatedFields = relatedFields
        
    def getFieldName(self):
        return self._fieldName
    
    def getFieldBelongsTo(self):
        return self._fieldBelongsTo
    
    def getFieldDefaultValue(self):
        return self._fieldDefaultValue
    
    def getFieldDataType(self):
        return self._fieldDataType
    
    def getFieldDefaultOperator(self):
        return self._fieldDefaultOperator
    
    def getRelatedFields(self):
        return self._relatedFields
    
    def getEntityType(self):
        return self._entityType
    
    def display(self):
        return "entityType : "+str(self.getEntityType()) + " , fieldName : "+str(self.getFieldName()) + " , fieldBelongsTo: "+str(self.getFieldBelongsTo())+ " , fieldDataType: "+str(self.getFieldDataType())+" , fieldOperator: "+str(self.getFieldDefaultOperator())+" , fieldDefaultValue: "+str(self.getFieldDefaultValue())+" , relatedFields: "+str(self.getRelatedFields())
        


def getFieldDefinaton(attName):
    
    if attName in WORKFLOW_ATTRIBUTES:
        return _getWorkFlowFieldDefination(attName)
    elif attName in ACTIVITY_ATTRIBUTES:
        return _getActivityFieldDefination(attName)
    elif attName in CONSULT_DETAIL_ATTRIBUTES:
        return _getConsultFieldDefination(attName)
    else:
        return None

def _getWorkFlowFieldDefination(attName):
    
    #print("asasasa")
    
    attributeDef = AttributeDefination(WORKFLOW_ATTRIBUTE_NAME_MAP.get(attName))
    
    #print("====ATTRIBUTE DEF====")
    
    #print(attributeDef.display())
    
    return WAFieldDefination(fieldName=attributeDef.getName(),
                             entityType=attributeDef.getEntityType(),
                             fieldBelongsTo='WORKFLOW',
                             fieldDefaultValue=attributeDef.getDefaultData(),
                             fieldDataType=attributeDef.getDataType(),
                             fieldDefaultOperator=attributeDef.getDefaultOperator(),
                             relatedFields = attributeDef.getRelatedFields())
        
        

def _getActivityFieldDefination(attName):
    
    attributeDef = AttributeDefination(ACTIVITY_ATTRIBUTE_NAME_MAP.get(attName))
    
    #print("====ATTRIBUTE DEF====")
    
    #print(attributeDef.display())
    
    return WAFieldDefination(fieldName=attributeDef.getName(),
                             entityType=attributeDef.getEntityType(),
                             fieldBelongsTo='ACTIVITY',
                             fieldDefaultValue=attributeDef.getDefaultData(),
                             fieldDataType=attributeDef.getDataType(),
                             fieldDefaultOperator=attributeDef.getDefaultOperator(),
                             relatedFields = attributeDef.getRelatedFields())
    

def _getConsultFieldDefination(attName):
    
    attributeDef = AttributeDefination(CONSULT_DETAIL_ATTRIBUTE_NAME_MAP.get(attName))
    
    #print("====ATTRIBUTE DEF====")
    
    #print(attributeDef.display())
    
    return WAFieldDefination(fieldName=attributeDef.getName(),
                             entityType=attributeDef.getEntityType(),
                             fieldBelongsTo='CONSULT_DETAIL',
                             fieldDefaultValue=attributeDef.getDefaultData(),
                             fieldDataType=attributeDef.getDataType(),
                             fieldDefaultOperator=attributeDef.getDefaultOperator(),
                             relatedFields = attributeDef.getRelatedFields())