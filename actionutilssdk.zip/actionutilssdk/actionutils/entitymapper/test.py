'''
Created on 02-Jul-2019

@author: asarkar
'''
from actionutils.entitymapper.entityDef import EntityDef


t1 =[{'index': 1, 'value': 'NOT', 'entity': 'logicalOperator', 'consumed': 'N'}, 
   {'index': 2, 'value': 'assigned', 'entity': 'caseStatus', 'consumed': 'N'}, 
   {'index': 3, 'value': {'to': '2019-03-20T00:00:00.000-05:00', 'from': '2019-03-17T00:00:00.000-05:00'}, 'entity': 'time', 'consumed': 'N'}, 
   {'index': 4, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, 
   {'index': 5, 'value': 'consulted with', 'entity': 'consultedwith', 'consumed': 'N'}, 
   {'index': 6, 'value': 'me', 'entity': 'consultant', 'consumed': 'N'}, 
   {'index': 7, 'value': '2019-03-20T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}]


t2 = [{"index":1,"entity":"logicalOperator","value":"NOT","consumed":"N"},
                         {"index": 2, "entity": "caseStatus", "value": "assigned", "consumed": "N"},
                         {"index": 3, "entity": "time", "value": {"to":"DATE1","from":"DATE2"}, "consumed": "N"},
                         {"index": 4, "entity": "condition", "value": "OR", "consumed": "N"},
                         {"index": 5, "entity": "caseStatus", "value": "due", "consumed": "N"},
                         {"index": 6, "entity": "time", "value": {"to": "DATE1", "from": "DATE2"}, "consumed": "N"},
                         {"index": 7, "entity": "caseStatus", "value": "assigned", "consumed": "N"},
                         {"index": 8, "entity": "time", "value": {"to": "DATE1", "from": "DATE2"}, "consumed": "N"},
                         {"index":9,"entity":"logicalOperator","value":"NOT","consumed":"N"},
                         {"index": 10, "entity": "caseStatus", "value": "assigned", "consumed": "N"},
                         {"index": 11, "entity": "time", "value": {"to":"DATE3","from":"DATE4"}, "consumed": "N"}
                         ]


t3 = [{'index': 1, 'value': 'overdue', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 2, 'value': '2019-07-22T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}]


t4 = [{'index': 1, 'value': 'overdue', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 2, 'value': '2019-07-22T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}, {'index': 3, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, {'index': 4, 'value': 'due', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 5, 'value': '2019-07-23T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}]

t5 = [{'index': 1, 'value': 'overdue', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 2, 'value': '2019-07-22T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}, {'index': 3, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, {'index': 4, 'value': 'due', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 5, 'value': '2019-07-23T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}, {'index': 6, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, {'index': 7, 'value': 'consulted', 'entity': 'caseStatus', 'consumed': 'N'}]

t6 = [{'index': 1, 'value': 'overdue', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 2, 'value': '2019-07-22T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}, {'index': 3, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, {'index': 4, 'value': 'due', 'entity': 'caseStatus', 'consumed': 'N'}, {'index': 5, 'value': '2019-07-23T00:00:00.000-05:00', 'entity': 'time', 'consumed': 'N'}, {'index': 6, 'value': 'OR', 'entity': 'condition', 'consumed': 'N'}, {'index': 7, 'value': 'reverted', 'entity': 'caseStatus', 'consumed': 'N'}]


primaryEntityList=['caseStatus','consultedwith']
secondaryEntityList=["time",'consultant']


subENameMap = {}
subENameMap['consultedwith']="consulted with"


entityMapperObj = EntityDef(t6,primaryEntityList,subENameMap)
list = entityMapperObj.getRetrivedEntities()
print("========???????=======")
print(list)
