'''
Created on 02-Jul-2019

@author: asarkar
'''
from actionutils.entitymapper.primaryEntity import PrimaryEntity

class SecondaryEntity(object):
    '''
    classdocs
    '''


    def __init__(self, PrimaryEntity):
        '''
        Constructor
        '''
        