'''
Created on 02-Jul-2019

@author: asarkar
'''

class PrimaryEntity(object):
    '''
    classdocs
    '''


    def __init__(self, name,dataType,operator=None,entityValue=None,defaultValue=None,relatedEntities=[]):
        '''
        Constructor
        '''
        self.name=name
        self.dataType=dataType
        self.operator=operator
        self.entityValue=entityValue
        self.defaultValue=defaultValue
        self.relatedEntities=relatedEntities
        
    def setOperator(self,operator):
        self.operator = operator
        
    def setValue(self,entityValue):
        self.entityValue = entityValue
        
    def addRelatedEntity(self,relatedEntity):
        
        self.relatedEntities.append(relatedEntity)