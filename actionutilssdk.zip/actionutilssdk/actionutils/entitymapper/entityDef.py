'''
Created on 02-Jul-2019

@author: asarkar
'''
#from aaa import primaryEntityList
from actionutils.entitymapper.myValueMapper import getFieldDefinaton


LOGICAL_OPERATOR = "logicalOperator"
CONDITION = "condition"


class EntityDef(object):
    '''
    classdocs
    '''


    def __init__(self, extractedEntityMapList,primaryEntityList,subENameMap):
        '''
        Constructor
        '''
        self.extractedEntityMapList = extractedEntityMapList
        self.primaryEntityList = primaryEntityList
        self.entityFormatNameMap = subENameMap
        
        #self._formatedEntityName()
        
        
    def _formatedEntityName(self):
        
        for extractedEntityMap in self.extractedEntityMapList:
            if extractedEntityMap['entity'] in self.entityFormatNameMap:
                print("00000")
                print("Inside")
                extractedEntityMap['entity'] = self.entityFormatNameMap[extractedEntityMap['entity']]
                    
    def _getRelatedEntities(self,incrementedCount):
        print("_getRelatedEntities")
        
        newTempList = []
        
        extractedEntityObj = self.extractedEntityMapList[incrementedCount]
        
        entityValue = extractedEntityObj['value']
        entityName = extractedEntityObj['entity']
        
        if entityName == LOGICAL_OPERATOR or entityName == CONDITION:
            
            newTempList.append(self.extractedEntityMapList[incrementedCount])
            
            return incrementedCount,newTempList
        
        if entityName in self.primaryEntityList and entityValue !=None:

            fieldDef = getFieldDefinaton(entityValue)
            print(fieldDef)
            newTempList.append(self.extractedEntityMapList[incrementedCount])
            
            if len(fieldDef.getRelatedFields())>0:
                incrementedCount = incrementedCount + 1
                for rf in fieldDef.getRelatedFields():
                    print(rf)
                    #print(rf['entityType'])
                    relatedfieldName = rf['fieldName']
                    relatedfieldDef = getFieldDefinaton(relatedfieldName)
                    if incrementedCount > len(self.extractedEntityMapList)-1:
                        return incrementedCount,newTempList
                        
                    print(incrementedCount)
                    print(len(self.extractedEntityMapList))
                    print(self.extractedEntityMapList[incrementedCount]['entity'])
                    if relatedfieldDef.getEntityType() == self.extractedEntityMapList[incrementedCount]['entity']:
                        if self.extractedEntityMapList[incrementedCount]['entity'] == LOGICAL_OPERATOR or self.extractedEntityMapList[incrementedCount]['entity'] == CONDITION:
                            print("LOGICAL_OPERATOR OR CONDITION " + self.extractedEntityMapList[incrementedCount]['entity'])
                        else:
                            newTempList.append(self.extractedEntityMapList[incrementedCount])
                        
                        return incrementedCount,newTempList
                        
                
                return incrementedCount,newTempList
            
            else:
                
                incrementedCount = incrementedCount + 1
                print("fieldDef.getEntityType()")
                print(fieldDef.getEntityType())
                if incrementedCount > len(self.extractedEntityMapList)-1:
                    return incrementedCount,newTempList
                      
                print(self.extractedEntityMapList[incrementedCount]['entity'])
                if fieldDef.getEntityType() == self.extractedEntityMapList[incrementedCount]['entity']:
                    if self.extractedEntityMapList[incrementedCount]['entity'] == LOGICAL_OPERATOR or self.extractedEntityMapList[incrementedCount]['entity'] == CONDITION:
                        print("LOGICAL_OPERATOR OR CONDITION " + self.extractedEntityMapList[incrementedCount]['entity'])
                    else:
                        newTempList.append(self.extractedEntityMapList[incrementedCount])
  
                    return incrementedCount,newTempList
                
            
            
            
    
    
    def _groupExtractedEntities(self,extractedEntityMap,nextIndex,mytmp):
        
        extractedEntityMap = self.extractedEntityMapList[nextIndex]
        fieldDef = getFieldDefinaton(extractedEntityMap['entity'])
        extractedEntityMap['consumed']='Y'
        if fieldDef == None:
            mytmp.append(extractedEntityMap)
            #print("add to tmp")    
        else:
            if fieldDef.getRelatedFields()!=None and len(fieldDef.getRelatedFields())==0:
                print("RelatedField is empty")
            else:
                print("RelatedField is not empty")
        
        return nextIndex,mytmp
    
        
    def getRetrivedEntities(self):
        '''
        Create dsl based on attributeValueMapper
        '''
        #print(self.extractedEntityMapList)
        list = []
        count = 0
        print("Counter ====>>>>")
        print(count)
        
        while (count < len(self.extractedEntityMapList)):
            
            tmpList = []
            
            if self.extractedEntityMapList[count]['entity'] == CONDITION:
                print("Condition Found, add to templist, increment the count by 1 and move")
                tmpList.append(self.extractedEntityMapList[count])
                list.append(tmpList)
                count = count + 1
            
            elif self.extractedEntityMapList[count]['entity'] == LOGICAL_OPERATOR:
                print("Logical operator Found,extract primary entity and secondary entity (if found),  add to templist, increment the count by next count recieve and move")
                tmpList.append(self.extractedEntityMapList[count])
                newCount,newTempList = self._getRelatedEntities(count+1)
                for newTmp in newTempList:
                    tmpList.append(newTmp)
                list.append(tmpList)
                count = newCount + 1
                
            elif self.extractedEntityMapList[count]['entity'] in self.primaryEntityList:
                print("primaryEntityList Found,extract primary entity and secondary entity (if found),  add to templist, increment the count by next count recieve and move")
                newCount,newTempList = self._getRelatedEntities(count)
                for newTmp in newTempList:
                    tmpList.append(newTmp)
                list.append(tmpList)
                count = newCount + 1
                
            else:
                count = count + 1
        
        
        return list